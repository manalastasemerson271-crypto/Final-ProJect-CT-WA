<?php
require_once __DIR__ . '/auth.php';
require_login();

$errors = [];
$statuses = ['pending', 'in_progress', 'completed'];
$isAdmin = $_SESSION['role'] === 'admin';
$userId = (int) $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!valid_csrf_token($_POST['csrf_token'] ?? null)) {
        $errors[] = 'The form expired or was invalid. Please try again.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'create' || $action === 'update') {
            $taskId = filter_var($_POST['task_id'] ?? null, FILTER_VALIDATE_INT);
            $title = trim($_POST['title'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $dueDate = trim($_POST['due_date'] ?? '');
            $status = $_POST['status'] ?? 'pending';

            if ($action === 'update' && (!$taskId || $taskId < 1)) {
                $errors[] = 'Invalid task.';
            }
            if ($title === '' || strlen($title) > 150) {
                $errors[] = 'Task title is required and must be no more than 150 characters.';
            }
            if (strlen($description) > 5000) {
                $errors[] = 'Description must be no more than 5000 characters.';
            }
            if (!in_array($status, $statuses, true)) {
                $errors[] = 'Choose a valid task status.';
            }
            if ($dueDate !== '') {
                $date = DateTimeImmutable::createFromFormat('!Y-m-d', $dueDate);
                $dateErrors = DateTimeImmutable::getLastErrors();
                if (!$date || ($dateErrors !== false && ($dateErrors['warning_count'] || $dateErrors['error_count']))) {
                    $errors[] = 'Enter a valid due date.';
                }
            }

            if (!$errors) {
                if ($action === 'create') {
                    $stmt = $conn->prepare('INSERT INTO tasks (user_id, title, description, due_date, status) VALUES (?, ?, ?, NULLIF(?, \'\'), ?)');
                    $stmt->bind_param('issss', $userId, $title, $description, $dueDate, $status);
                    $stmt->execute();
                    $stmt->close();
                } elseif ($isAdmin) {
                    $stmt = $conn->prepare('UPDATE tasks SET title = ?, description = ?, due_date = NULLIF(?, \'\'), status = ? WHERE id = ?');
                    $stmt->bind_param('ssssi', $title, $description, $dueDate, $status, $taskId);
                    $stmt->execute();
                    $updated = $stmt->affected_rows;
                    $stmt->close();
                    if ($updated === 0) {
                        $check = $conn->prepare('SELECT id FROM tasks WHERE id = ?');
                        $check->bind_param('i', $taskId);
                        $check->execute();
                        $exists = $check->get_result()->num_rows > 0;
                        $check->close();
                        if (!$exists) {
                            $errors[] = 'Task not found.';
                        }
                    }
                } else {
                    $stmt = $conn->prepare('UPDATE tasks SET title = ?, description = ?, due_date = NULLIF(?, \'\'), status = ? WHERE id = ? AND user_id = ?');
                    $stmt->bind_param('ssssii', $title, $description, $dueDate, $status, $taskId, $userId);
                    $stmt->execute();
                    $updated = $stmt->affected_rows;
                    $stmt->close();
                    if ($updated === 0) {
                        $check = $conn->prepare('SELECT id FROM tasks WHERE id = ? AND user_id = ?');
                        $check->bind_param('ii', $taskId, $userId);
                        $check->execute();
                        $exists = $check->get_result()->num_rows > 0;
                        $check->close();
                        if (!$exists) {
                            $errors[] = 'Task not found or you do not have permission to edit it.';
                        }
                    }
                }

                if (!$errors) {
                    header('Location: dashboard.php');
                    exit;
                }
            }
        } elseif ($action === 'delete') {
            $taskId = filter_var($_POST['task_id'] ?? null, FILTER_VALIDATE_INT);
            if (!$taskId || $taskId < 1) {
                $errors[] = 'Invalid task.';
            } else {
                if ($isAdmin) {
                    $stmt = $conn->prepare('DELETE FROM tasks WHERE id = ?');
                    $stmt->bind_param('i', $taskId);
                } else {
                    $stmt = $conn->prepare('DELETE FROM tasks WHERE id = ? AND user_id = ?');
                    $stmt->bind_param('ii', $taskId, $userId);
                }
                $stmt->execute();
                $deleted = $stmt->affected_rows;
                $stmt->close();
                if ($deleted === 0) {
                    $errors[] = 'Task not found or you do not have permission to delete it.';
                } else {
                    header('Location: dashboard.php');
                    exit;
                }
            }
        } else {
            $errors[] = 'Invalid action.';
        }
    }
}

$editingTask = null;
$editId = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT);
if ($editId) {
    if ($isAdmin) {
        $stmt = $conn->prepare('SELECT id, user_id, title, description, due_date, status FROM tasks WHERE id = ?');
        $stmt->bind_param('i', $editId);
    } else {
        $stmt = $conn->prepare('SELECT id, user_id, title, description, due_date, status FROM tasks WHERE id = ? AND user_id = ?');
        $stmt->bind_param('ii', $editId, $userId);
    }
    $stmt->execute();
    $editingTask = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$editingTask) {
        http_response_code(404);
        exit('Task not found or you do not have permission to access it.');
    }
}

if ($isAdmin) {
    $tasks = $conn->query('SELECT tasks.id, tasks.user_id, tasks.title, tasks.description, tasks.due_date, tasks.status, users.username FROM tasks JOIN users ON users.id = tasks.user_id ORDER BY tasks.created_at DESC');
} else {
    $stmt = $conn->prepare('SELECT id, user_id, title, description, due_date, status, NULL AS username FROM tasks WHERE user_id = ? ORDER BY created_at DESC');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $tasks = $stmt->get_result();
}

$formTask = $editingTask ?? [
    'id' => '',
    'title' => '',
    'description' => '',
    'due_date' => '',
    'status' => 'pending',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My tasks | Taskwise</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<main class="app-shell">
    <header class="topbar">
        <a class="brand" href="dashboard.php"><span class="brand-mark">✓</span> Taskwise</a>
        <div class="topbar-actions">
            <?php if ($isAdmin): ?><a href="users.php">User management</a><?php endif; ?>
            <span class="user-chip"><span class="user-dot"></span><?= h($_SESSION['username']) ?> · <?= h(ucfirst($_SESSION['role'])) ?></span>
            <form method="post" action="logout.php">
                <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
                <button class="secondary" type="submit">Sign out</button>
            </form>
        </div>
    </header>

    <div class="page-heading">
        <h1><?= $isAdmin ? 'Task overview' : 'My tasks' ?></h1>
        <p><?= $isAdmin ? 'Manage tasks across your team.' : 'Keep track of what needs to get done.' ?></p>
    </div>

    <?php foreach ($errors as $error): ?>
    <div class="alert error"><?= h($error) ?></div>
    <?php endforeach; ?>

    <div class="task-layout">
        <section class="panel">
            <h2><?= $editingTask ? 'Update task' : 'Add a task' ?></h2>
            <form class="task-form" method="post" action="dashboard.php<?= $editingTask ? '?edit=' . (int) $editingTask['id'] : '' ?>">
                <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
                <input type="hidden" name="action" value="<?= $editingTask ? 'update' : 'create' ?>">
                <?php if ($editingTask): ?><input type="hidden" name="task_id" value="<?= (int) $editingTask['id'] ?>"><?php endif; ?>
                <div class="field">
                    <label for="title">Task title</label>
                    <input id="title" name="title" maxlength="150" placeholder="e.g. Prepare project report" value="<?= h($formTask['title']) ?>" required>
                </div>
                <div class="field">
                    <label for="description">Description <span class="count">(optional)</span></label>
                    <textarea id="description" name="description" maxlength="5000" placeholder="Add a few details..."><?= h($formTask['description']) ?></textarea>
                </div>
                <div class="field">
                    <label for="due_date">Due date <span class="count">(optional)</span></label>
                    <input id="due_date" type="date" name="due_date" value="<?= h($formTask['due_date'] ?? '') ?>">
                </div>
                <div class="field">
                    <label for="status">Status</label>
                    <select id="status" name="status">
                        <?php foreach ($statuses as $status): ?>
                        <option value="<?= h($status) ?>" <?= $formTask['status'] === $status ? 'selected' : '' ?>><?= h(ucwords(str_replace('_', ' ', $status))) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-actions">
                    <button type="submit"><?= $editingTask ? 'Save changes' : '＋ Add task' ?></button>
                    <?php if ($editingTask): ?><a href="dashboard.php">Cancel</a><?php endif; ?>
                </div>
            </form>
        </section>

        <section class="panel">
            <div class="section-title">
                <h2><?= $isAdmin ? 'All tasks' : 'Your task list' ?></h2>
                <span class="count"><?= (int) $tasks->num_rows ?> <?= $tasks->num_rows === 1 ? 'task' : 'tasks' ?></span>
            </div>
            <?php if ($tasks->num_rows === 0): ?>
            <div class="empty-state">
                <span class="empty-icon">✓</span>
                <h3>No tasks yet</h3>
                <p>Add your first task using the form to get started.</p>
            </div>
            <?php else: ?>
            <div class="task-list">
                <?php while ($task = $tasks->fetch_assoc()): ?>
                <article class="task-card">
                    <div>
                        <h3><?= h($task['title']) ?></h3>
                        <?php if ($task['description'] !== ''): ?><p class="task-description"><?= h($task['description']) ?></p><?php endif; ?>
                        <div class="task-meta">
                            <span class="badge <?= h($task['status']) ?>"><?= h(ucwords(str_replace('_', ' ', $task['status']))) ?></span>
                            <?php if ($task['due_date']): ?><span>Due <?= h(date('M j, Y', strtotime($task['due_date']))) ?></span><?php endif; ?>
                            <?php if ($isAdmin): ?><span>Owner: <?= h($task['username']) ?></span><?php endif; ?>
                        </div>
                    </div>
                    <div class="task-actions">
                        <a class="button secondary" href="dashboard.php?edit=<?= (int) $task['id'] ?>">Edit</a>
                        <form method="post" action="dashboard.php" onsubmit="return confirm('Delete this task?');">
                            <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="task_id" value="<?= (int) $task['id'] ?>">
                            <button class="danger" type="submit">Delete</button>
                        </form>
                    </div>
                </article>
                <?php endwhile; ?>
            </div>
            <?php endif; ?>
        </section>
    </div>
</main>
</body>
</html>
<?php
if (!$isAdmin) {
    $stmt->close();
}
?>
