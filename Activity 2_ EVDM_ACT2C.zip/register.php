<?php
require_once __DIR__ . '/auth.php';

$mess = [];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uname = trim($_POST['uname'] ?? '');
    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';

    if (!valid_csrf_token($_POST['csrf_token'] ?? null)) {
        $errors[] = 'The form expired or was invalid. Please try again.';
    }
    if ($uname === '' || strlen($uname) > 50) {
        $errors[] = 'Username is required and must be no more than 50 characters.';
    }
    if (strlen($password) < 8) {
        $errors[] = 'Password must be at least 8 characters long.';
    }
    if ($password !== $password2) {
        $errors[] = 'Passwords should match.';
    }

    if (!$errors) {
        $check = $conn->prepare('SELECT id FROM users WHERE username = ?');
        $check->bind_param('s', $uname);
        $check->execute();
        $exists = $check->get_result()->num_rows > 0;
        $check->close();

        if ($exists) {
            $errors[] = 'That username is already in use.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, password, role, status) VALUES (?, ?, 'user', 'pending')");
            $stmt->bind_param('ss', $uname, $hash);
            $stmt->execute();
            $stmt->close();
            $mess[] = 'Registered successfully. Please wait for admin approval of your account.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create account | Taskwise</title>
<link rel="stylesheet" href="style.css">
</head>
<body class="auth-shell">
<main class="auth-card">
<a class="brand" href="index.php"><span class="brand-mark">✓</span> Taskwise</a>
<h1>Create your account</h1>
<p class="subheading">Stay organized and keep your work moving.</p>
<?php foreach ($errors as $error): ?>
<div class="alert error"><?= h($error) ?></div>
<?php endforeach; ?>
<?php foreach ($mess as $m): ?>
<div class="alert success"><?= h($m) ?></div>
<?php endforeach; ?>
<form action="" method="post">
<input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
<div class="field">
    <label for="uname">Username</label>
    <input type="text" name="uname" id="uname" maxlength="50" placeholder="Choose a username" autocomplete="username" required autofocus>
</div>
<div class="field">
    <label for="password">Password</label>
    <input type="password" name="password" id="password" minlength="8" placeholder="At least 8 characters" autocomplete="new-password" required>
</div>
<div class="field">
    <label for="password2">Confirm password</label>
    <input type="password" name="password2" id="password2" minlength="8" placeholder="Enter your password again" autocomplete="new-password" required>
</div>
<button class="submit" type="submit">Create account</button>
</form>
<p class="auth-foot">Already have an account? <a href="index.php">Sign in</a></p>
</main>
</body>
</html>