<?php
require_once __DIR__ . '/auth.php';
require_admin();

$errors = [];
$currentUserId = (int) $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!valid_csrf_token($_POST['csrf_token'] ?? null)) {
        $errors[] = 'The form expired or was invalid. Please try again.';
    } else {
        $action = $_POST['action'] ?? '';
        $targetId = filter_var($_POST['user_id'] ?? null, FILTER_VALIDATE_INT);

        if (!$targetId || $targetId < 1) {
            $errors[] = 'Invalid user.';
        } elseif ($action === 'update') {
            $role = $_POST['role'] ?? '';
            $status = $_POST['status'] ?? '';
            if (!in_array($role, ['admin', 'user'], true) || !in_array($status, ['pending', 'approved'], true)) {
                $errors[] = 'Choose a valid role and account status.';
            } elseif ($targetId === $currentUserId && ($role !== 'admin' || $status !== 'approved')) {
                $errors[] = 'You cannot remove your own administrator access or approval.';
            } else {
                $stmt = $conn->prepare('UPDATE users SET role = ?, status = ? WHERE id = ?');
                $stmt->bind_param('ssi', $role, $status, $targetId);
                $stmt->execute();
                $updated = $stmt->affected_rows;
                $stmt->close();
                if ($updated === 0) {
                    $check = $conn->prepare('SELECT id FROM users WHERE id = ?');
                    $check->bind_param('i', $targetId);
                    $check->execute();
                    $exists = $check->get_result()->num_rows > 0;
                    $check->close();
                    if (!$exists) {
                        $errors[] = 'User not found.';
                    } else {
                        header('Location: users.php');
                        exit;
                    }
                } else {
                    header('Location: users.php');
                    exit;
                }
            }
        } elseif ($action === 'delete') {
            if ($targetId === $currentUserId) {
                $errors[] = 'You cannot delete your own account while signed in.';
            } else {
                $stmt = $conn->prepare('DELETE FROM users WHERE id = ?');
                $stmt->bind_param('i', $targetId);
                $stmt->execute();
                $deleted = $stmt->affected_rows;
                $stmt->close();
                if ($deleted === 0) {
                    $errors[] = 'User not found.';
                } else {
                    header('Location: users.php');
                    exit;
                }
            }
        } else {
            $errors[] = 'Invalid action.';
        }
    }
}

$users = $conn->query('SELECT id, username, role, status FROM users ORDER BY id');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User management | Taskwise</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<main class="app-shell">
<header class="topbar">
    <a class="brand" href="dashboard.php"><span class="brand-mark">✓</span> Taskwise</a>
    <div class="topbar-actions">
        <a href="dashboard.php">Task overview</a>
        <form method="post" action="logout.php">
            <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
            <button class="secondary" type="submit">Sign out</button>
        </form>
    </div>
</header>
<div class="page-heading">
    <h1>User management</h1>
    <p>Review accounts, approve access, and manage roles.</p>
</div>
<?php foreach ($errors as $error): ?>
<div class="alert error"><?= h($error) ?></div>
<?php endforeach; ?>
<section class="panel">
    <div class="section-title">
        <h2>Accounts</h2>
        <span class="count"><?= (int) $users->num_rows ?> <?= $users->num_rows === 1 ? 'account' : 'accounts' ?></span>
    </div>
    <?php if ($users->num_rows === 0): ?>
    <div class="empty-state"><p>No accounts to show.</p></div>
    <?php else: ?>
    <div class="table-wrap">
        <table>
            <thead><tr><th>User</th><th>Role</th><th>Status</th><th>Manage account</th></tr></thead>
            <tbody>
            <?php while ($user = $users->fetch_assoc()): ?>
            <tr>
                <td>
                    <span class="user-name"><?= h($user['username']) ?></span>
                    <?php if ((int) $user['id'] === $currentUserId): ?><span class="user-self">You</span><?php endif; ?>
                </td>
                <td><span class="badge <?= h($user['role']) ?>"><?= h(ucfirst($user['role'])) ?></span></td>
                <td><span class="badge <?= h($user['status']) ?>"><?= h(ucfirst($user['status'])) ?></span></td>
                <td>
                    <div class="user-controls">
                        <form method="post" action="users.php">
                            <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
                            <input type="hidden" name="user_id" value="<?= (int) $user['id'] ?>">
                            <input type="hidden" name="action" value="update">
                            <label class="sr-only" for="role-<?= (int) $user['id'] ?>">Role</label>
                            <select id="role-<?= (int) $user['id'] ?>" name="role">
                                <option value="user" <?= $user['role'] === 'user' ? 'selected' : '' ?>>User</option>
                                <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                            </select>
                            <label class="sr-only" for="status-<?= (int) $user['id'] ?>">Account status</label>
                            <select id="status-<?= (int) $user['id'] ?>" name="status">
                                <option value="pending" <?= $user['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                                <option value="approved" <?= $user['status'] === 'approved' ? 'selected' : '' ?>>Approved</option>
                            </select>
                            <button type="submit">Save</button>
                        </form>
                        <?php if ((int) $user['id'] !== $currentUserId): ?>
                        <form method="post" action="users.php" onsubmit="return confirm('Delete this user and all tasks they own?');">
                            <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
                            <input type="hidden" name="user_id" value="<?= (int) $user['id'] ?>">
                            <input type="hidden" name="action" value="delete">
                            <button class="danger" type="submit">Delete</button>
                        </form>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</section>
</main>
</body>
</html>
