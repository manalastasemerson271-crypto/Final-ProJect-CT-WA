<?php
require_once __DIR__ . '/auth.php';

if (!empty($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uname = trim($_POST['uname'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!valid_csrf_token($_POST['csrf_token'] ?? null)) {
        $errors[] = 'The form expired or was invalid. Please try again.';
    }

    if (!$errors) {
        $stmt = $conn->prepare('SELECT id, username, password, role, status FROM users WHERE username = ?');
        $stmt->bind_param('s', $uname);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        $passwordIsValid = false;
        if ($user) {
            $passwordInfo = password_get_info($user['password']);
            if ($passwordInfo['algoName'] !== 'unknown') {
                $passwordIsValid = password_verify($password, $user['password']);
            } elseif (hash_equals($user['password'], $password)) {
                $passwordIsValid = true;
                $newHash = password_hash($password, PASSWORD_DEFAULT);
                $upgrade = $conn->prepare('UPDATE users SET password = ? WHERE id = ?');
                $upgrade->bind_param('si', $newHash, $user['id']);
                $upgrade->execute();
                $upgrade->close();
            }
        }

        if (!$passwordIsValid) {
            $errors[] = 'Invalid username or password.';
        } elseif ($user['status'] !== 'approved') {
            $errors[] = 'Your account is not approved yet.';
        } elseif (!in_array($user['role'], ['admin', 'user'], true)) {
            $errors[] = 'Your account has an invalid access role. Contact an administrator.';
        } else {
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int) $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];

            header('Location: dashboard.php');
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign in | Taskwise</title>
<link rel="stylesheet" href="style.css">
</head>
<body class="auth-shell">
<main class="auth-card">
<a class="brand" href="index.php"><span class="brand-mark">✓</span> Taskwise</a>
<h1>Welcome back</h1>
<p class="subheading">Sign in to pick up where you left off.</p>
<?php foreach ($errors as $error): ?>
<div class="alert error"><?= h($error) ?></div>
<?php endforeach; ?>
<form action="" method="post">
<input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
<div class="field">
    <label for="uname">Username</label>
    <input type="text" name="uname" id="uname" placeholder="Your username" autocomplete="username" required autofocus>
</div>
<div class="field">
    <label for="password">Password</label>
    <input type="password" name="password" id="password" placeholder="Your password" autocomplete="current-password" required>
</div>
<button class="submit" type="submit">Sign in</button>
</form>
<p class="auth-foot">New to Taskwise? <a href="register.php">Create an account</a></p>
</main>
</body>
</html>